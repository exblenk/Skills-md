/*
 * Frida — Deep StoreKit 1 inspection
 * Confirmed: app uses classic Obj-C StoreKit 1 (not StoreKit 2, no 3rd-party SDK)
 *
 * This script captures:
 *  - Product IDs being queried (subscription SKUs)
 *  - Purchase attempts (addPayment)
 *  - Transaction state changes (purchased / failed / restored)
 *  - Receipt validation network calls
 *  - Premium flag reads from UserDefaults
 */

'use strict';
const TAG = '[SK1-DEEP]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) {
  console.error(`${TAG} ObjC runtime not available — abort`);
} else {

  // 1) Capture which Product IDs the app queries
  try {
    const SKProductsRequest = ObjC.classes.SKProductsRequest;
    const initSel = '- initWithProductIdentifiers:';
    Interceptor.attach(SKProductsRequest[initSel].implementation, {
      onEnter(args) {
        try {
          const ids = new ObjC.Object(args[2]); // NSSet<NSString>
          log('SKU-QUERY', `Product IDs requested: ${ids.toString()}`);
        } catch (e) {}
      }
    });
    log('hook', 'SKProductsRequest initWithProductIdentifiers:');
  } catch (e) { log('err', `SKProductsRequest: ${e}`); }

  // 2) Capture products returned by App Store
  try {
    const productsHook = ObjC.classes.SKProductsResponse;
    if (productsHook && productsHook['- products']) {
      Interceptor.attach(productsHook['- products'].implementation, {
        onLeave(retval) {
          try {
            const arr = new ObjC.Object(retval);
            const count = arr.count();
            log('SKU-RESP', `App Store returned ${count} products`);
            for (let i = 0; i < count.valueOf(); i++) {
              const p = arr.objectAtIndex_(i);
              log('SKU-RESP', `  → ${p.productIdentifier()}  price=${p.price()}  title="${p.localizedTitle()}"`);
            }
          } catch (e) {}
        }
      });
    }
  } catch (e) {}

  // 3) Purchase attempt (addPayment:)
  try {
    Interceptor.attach(ObjC.classes.SKPaymentQueue['- addPayment:'].implementation, {
      onEnter(args) {
        try {
          const p = new ObjC.Object(args[2]);
          log('BUY', `addPayment: product=${p.productIdentifier()} qty=${p.quantity()}`);
        } catch (e) {}
      }
    });
    log('hook', 'SKPaymentQueue addPayment:');
  } catch (e) {}

  // 4) Restore purchases
  try {
    Interceptor.attach(ObjC.classes.SKPaymentQueue['- restoreCompletedTransactions'].implementation, {
      onEnter() { log('RESTORE', 'restoreCompletedTransactions called'); }
    });
  } catch (e) {}

  // 5) Transaction state observer — what the delegate sees
  //    SKPaymentTransactionStates: 0=Purchasing 1=Purchased 2=Failed 3=Restored 4=Deferred
  const stateName = ['Purchasing','Purchased','Failed','Restored','Deferred'];
  try {
    const tx = ObjC.classes.SKPaymentTransaction;
    Interceptor.attach(tx['- transactionState'].implementation, {
      onLeave(retval) {
        const s = retval.toInt32();
        if (s >= 0 && s <= 4) log('TX-STATE', `${stateName[s]} (${s})`);
      }
    });
  } catch (e) {}

  // 6) Receipt URL access — when app reads the local App Store receipt
  try {
    const NSBundle = ObjC.classes.NSBundle;
    Interceptor.attach(NSBundle['- appStoreReceiptURL'].implementation, {
      onLeave(retval) {
        try {
          const url = new ObjC.Object(retval);
          log('RECEIPT', `appStoreReceiptURL → ${url.toString()}`);
        } catch (e) {}
      }
    });
  } catch (e) {}

  // 7) Network — receipt verification + entitlement endpoints
  try {
    const NSURLSession = ObjC.classes.NSURLSession;
    const sel = '- dataTaskWithRequest:completionHandler:';
    if (NSURLSession[sel]) {
      Interceptor.attach(NSURLSession[sel].implementation, {
        onEnter(args) {
          try {
            const req = new ObjC.Object(args[2]);
            const url = req.URL().absoluteString().toString();
            const method = req.HTTPMethod().toString();
            if (/buy\.itunes|sandbox\.itunes|verifyReceipt|receipt|purchase|subscri|entitle|premium|kie\.ai|cloudfunctions|amazonaws/i.test(url)) {
              log('NET', `${method} ${url}`);
              const body = req.HTTPBody();
              if (body && !body.isNull()) {
                try {
                  const s = ObjC.classes.NSString.alloc().initWithData_encoding_(body, 4); // UTF-8
                  if (s) log('NET-BODY', `${s.toString().slice(0, 300)}`);
                } catch (e) {}
              }
            }
          } catch (e) {}
        }
      });
      log('hook', 'NSURLSession dataTaskWithRequest:completionHandler:');
    }
  } catch (e) { log('err', `NSURLSession: ${e}`); }

  // 8) UserDefaults — premium flag + counters
  try {
    const NSUserDefaults = ObjC.classes.NSUserDefaults;
    const watchKeys = /premium|purchase|subscri|credit|count|quota|grok|seedance|omni|video|isPro|isPaid/i;
    Interceptor.attach(NSUserDefaults['- setObject:forKey:'].implementation, {
      onEnter(args) {
        try {
          const key = new ObjC.Object(args[3]).toString();
          if (watchKeys.test(key)) {
            const val = new ObjC.Object(args[2]).toString();
            log('UD-WRITE', `${key} = ${val}`);
          }
        } catch (e) {}
      }
    });
    Interceptor.attach(NSUserDefaults['- boolForKey:'].implementation, {
      onEnter(args) {
        try {
          const key = new ObjC.Object(args[2]).toString();
          if (watchKeys.test(key)) this._k = key;
        } catch (e) {}
      },
      onLeave(retval) {
        if (this._k) log('UD-READ', `${this._k} → ${retval.toInt32() ? 'true' : 'false'}`);
      }
    });
    log('hook', 'NSUserDefaults setObject + boolForKey');
  } catch (e) {}

  console.log(`\n${TAG} ready — trigger purchase / restore / premium flow now.\n`);
}
