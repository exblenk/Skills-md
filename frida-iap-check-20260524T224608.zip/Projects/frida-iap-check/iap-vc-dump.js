/*
 * Frida — Deep dump of IAPViewController + key-finding scan
 *
 * 1. Lists every method and ivar of AI_Video_Maker.IAPViewController
 * 2. Hooks every Bool-returning method to trace decisions
 * 3. Scans NSUserDefaults for ALL distinct keys touched
 *    (so we find every premium-flag the app uses, not just isPremiumUser)
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l iap-vc-dump.js --no-pause
 */

'use strict';
const TAG = '[IAP-VC]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

// ────────────────────────────────────────────────────────────
// 1) Track every distinct UserDefaults key the app touches
// ────────────────────────────────────────────────────────────
const seenKeys = new Set();
const ud = ObjC.classes.NSUserDefaults;
['- boolForKey:', '- objectForKey:', '- integerForKey:', '- stringForKey:', '- valueForKey:', '- setObject:forKey:', '- setBool:forKey:', '- setInteger:forKey:']
  .forEach(sel => {
    try {
      const impl = ud[sel].implementation;
      Interceptor.attach(impl, {
        onEnter(args) {
          try {
            // key is last arg for getters, last arg also for setters (forKey:)
            const keyArg = sel.startsWith('- set') ? args[3] : args[2];
            const k = new ObjC.Object(keyArg).toString();
            if (!seenKeys.has(k) && !/^(WebKit|NSConst|__unique|com\.google\.GTM|Log|InternalDebug|WebProcess|Modern|GET_)/i.test(k)) {
              seenKeys.add(k);
              log('UD-KEY', `${sel.includes('set') ? 'WRITE' : 'READ'}  ${k}`);
            }
          } catch (_) {}
        }
      });
    } catch (_) {}
  });

// ────────────────────────────────────────────────────────────
// 2) Dump IAPViewController
// ────────────────────────────────────────────────────────────
const dumpIAP = () => {
  const cls = ObjC.classes['AI_Video_Maker.IAPViewController'];
  if (!cls) return false;
  log('class', '═══ IAPViewController methods ═══');
  cls.$ownMethods.sort().forEach(m => log('m', `  ${m}`));
  log('class', `total: ${cls.$ownMethods.length}`);

  try {
    const ivars = Object.keys(cls.$ivars || {});
    if (ivars.length) {
      log('ivars', '═══ IAPViewController ivars ═══');
      ivars.sort().forEach(i => log('iv', `  ${i}`));
    }
  } catch (_) {}

  // hook every method — log entry + return — to see decision flow
  cls.$ownMethods.forEach(m => {
    if (m === '- .cxx_destruct' || m === '- dealloc') return;
    try {
      Interceptor.attach(cls[m].implementation, {
        onEnter() { this._m = m; },
        onLeave(retval) {
          // Try to read retval as int (BOOL/NSInteger)
          let rv = 'void/obj';
          try {
            const i = retval.toInt32();
            if (i >= -1 && i <= 1) rv = i;
          } catch (_) {}
          log('CALL', `IAPVC ${this._m} → ${rv}`);
        }
      });
    } catch (e) {}
  });
  log('init', 'hooked all IAPViewController methods (tracing only)');
  return true;
};

let done = dumpIAP();
let n = 0;
const poller = setInterval(() => {
  n++;
  if (!done) done = dumpIAP();
  if (done || n > 30) clearInterval(poller);
}, 1000);

// ────────────────────────────────────────────────────────────
// 3) Also dump any class with these revealing names
// ────────────────────────────────────────────────────────────
setTimeout(() => {
  const filtered = Object.keys(ObjC.classes)
    .filter(c => c.startsWith('AI_Video_Maker') &&
      /Premium|Subscription|Purchase|Receipt|Paywall|Trial|Limit|Quota|VideoCount|Manager$/i.test(c));
  if (filtered.length) {
    log('related', '═══ other app classes worth checking ═══');
    filtered.sort().forEach(c => {
      const own = ObjC.classes[c].$ownMethods || [];
      log('c', `${c}  (${own.length} methods)`);
    });
  }
}, 2500);

console.log(`\n${TAG} ready — open Premium screen and try clicking a plan.\n`);
