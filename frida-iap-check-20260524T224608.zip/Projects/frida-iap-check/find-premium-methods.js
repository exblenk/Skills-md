/*
 * Frida — Search ALL app classes for premium-related methods
 *
 * Iterates every Obj-C class whose name contains "AI_Video_Maker"
 * (Swift mangled prefix for this app) and prints any method that
 * matches premium/subscription/iap keywords.
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l find-premium-methods.js --no-pause
 */

'use strict';
const TAG = '[FIND]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const APP_PREFIX = 'AI_Video_Maker';
const KEYWORDS = /premium|isPro\b|isPaid|isSubscribed|subscription|hasActive|checkReceipt|validateReceipt|verifyPurchase|isUserPremium|hasPurchased|unlock|paywall|entitlement|isFreeLimit|isLimit|canUse|videoCount|grok|seedance|omni/i;

const scan = () => {
  const allClasses = Object.keys(ObjC.classes);
  const appClasses = allClasses.filter(c => c.startsWith(APP_PREFIX));
  log('init', `found ${appClasses.length} classes with prefix ${APP_PREFIX}`);

  const hits = [];
  appClasses.forEach(cName => {
    try {
      const cls = ObjC.classes[cName];
      const own = cls.$ownMethods || [];
      own.forEach(m => {
        if (KEYWORDS.test(m)) hits.push({ cls: cName, method: m });
      });
    } catch (_) {}
  });

  if (hits.length === 0) {
    log('warn', 'no matches — paywall might not be loaded yet');
    return false;
  }

  log('result', `═══ ${hits.length} matches ═══`);
  hits.sort((a, b) => a.cls.localeCompare(b.cls)).forEach(h => {
    log('hit', `${h.cls}  →  ${h.method}`);
  });
  return true;
};

let done = scan();
let n = 0;
const poller = setInterval(() => {
  n++;
  if (!done) done = scan();
  if (done || n > 60) clearInterval(poller);
}, 1000);

// also dump every class that has "Premium" / "IAP" / "Subscription" in its name
const namedDump = () => {
  const candidates = Object.keys(ObjC.classes).filter(
    c => /Premium|IAP|Subscription|Paywall|Purchase/i.test(c)
  );
  if (!candidates.length) return;
  log('class-names', '═══ premium-related classes ═══');
  candidates.sort().forEach(c => log('cls', c));
};
setTimeout(namedDump, 3000);

console.log(`\n${TAG} scanning… open paywall and any premium-gated feature.\n`);
