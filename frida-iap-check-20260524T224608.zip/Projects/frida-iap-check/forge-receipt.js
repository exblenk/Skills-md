/*
 * Frida — Forge Apple verifyReceipt response
 *
 * Strategy:
 *  - Hook +[NSJSONSerialization JSONObjectWithData:options:error:]
 *  - If the parsed dict looks like Apple's receipt response (has "status" key)
 *    we patch it BEFORE returning to the app:
 *       status      → 0 (valid)
 *       latest_receipt_info → synthetic valid auto-renew subscription
 *       pending_renewal_info → matching entry
 *  - The app's own validation logic then writes isPremiumUser=YES naturally
 *    → no anti-tamper trigger
 *
 * This does NOT touch UserDefaults or call into StoreKit directly.
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l forge-receipt.js --no-pause
 */

'use strict';
const TAG = '[FORGE]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const NSJSONSerialization = ObjC.classes.NSJSONSerialization;
const NSDictionary        = ObjC.classes.NSDictionary;
const NSMutableDictionary = ObjC.classes.NSMutableDictionary;
const NSArray             = ObjC.classes.NSArray;
const NSNumber            = ObjC.classes.NSNumber;
const NSString            = ObjC.classes.NSString;

// far-future expiry: year 2099
const FAR_FUTURE_MS = '4070908800000';
const PRODUCT_YEAR  = 'gen_ai_yearly_2999';
const PRODUCT_WEEK  = 'gen_ai_weekly_999';

const looksLikeAppleReceipt = (dict) => {
  try {
    if (!dict) return false;
    // Apple responses always have "status" and usually "receipt" or "environment"
    return dict.objectForKey_('status') !== null &&
           (dict.objectForKey_('receipt') !== null ||
            dict.objectForKey_('environment') !== null ||
            dict.objectForKey_('latest_receipt') !== null);
  } catch (_) { return false; }
};

const buildValidReceiptInfo = (productId) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(NSString.stringWithString_(productId), 'product_id');
  d.setObject_forKey_(NSString.stringWithString_(FAR_FUTURE_MS), 'expires_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('1000000000000000'), 'transaction_id');
  d.setObject_forKey_(NSString.stringWithString_('1000000000000000'), 'original_transaction_id');
  d.setObject_forKey_(NSString.stringWithString_('1700000000000'), 'purchase_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('1700000000000'), 'original_purchase_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('0'), 'is_trial_period');
  d.setObject_forKey_(NSString.stringWithString_('0'), 'is_in_intro_offer_period');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'quantity');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'web_order_line_item_id');
  return d;
};

const buildRenewalInfo = (productId) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(NSString.stringWithString_(productId), 'product_id');
  d.setObject_forKey_(NSString.stringWithString_(productId), 'auto_renew_product_id');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'auto_renew_status');
  return d;
};

const patchAppleResponse = (mutable) => {
  // 1. status → 0
  mutable.setObject_forKey_(NSNumber.numberWithInt_(0), 'status');

  // 2. latest_receipt_info → [valid yearly + valid weekly]
  const arr = NSArray.arrayWithObjects_(
    buildValidReceiptInfo(PRODUCT_YEAR),
    buildValidReceiptInfo(PRODUCT_WEEK),
    null
  );
  mutable.setObject_forKey_(arr, 'latest_receipt_info');

  // 3. pending_renewal_info → matching
  const renewal = NSArray.arrayWithObjects_(
    buildRenewalInfo(PRODUCT_YEAR),
    buildRenewalInfo(PRODUCT_WEEK),
    null
  );
  mutable.setObject_forKey_(renewal, 'pending_renewal_info');

  // 4. environment → "Production" (some apps reject sandbox)
  mutable.setObject_forKey_(NSString.stringWithString_('Production'), 'environment');

  return mutable;
};

// ────────────────────────────────────────────────────────────
// Hook +[NSJSONSerialization JSONObjectWithData:options:error:]
// ────────────────────────────────────────────────────────────
const sel = '+ JSONObjectWithData:options:error:';
Interceptor.attach(NSJSONSerialization[sel].implementation, {
  onLeave(retval) {
    try {
      if (retval.isNull()) return;
      const obj = new ObjC.Object(retval);
      // Only NSDictionary
      if (!obj.isKindOfClass_(ObjC.classes.NSDictionary)) return;
      if (!looksLikeAppleReceipt(obj)) return;

      const oldStatus = obj.objectForKey_('status');
      log('HIT', `Apple receipt response — original status: ${oldStatus}`);

      // Build mutable copy
      const mutable = NSMutableDictionary.dictionaryWithDictionary_(obj);
      patchAppleResponse(mutable);

      // Replace retval — careful: must retain so it doesn't get freed
      const ptr = mutable.handle;
      retval.replace(ptr);
      mutable.retain();
      log('PATCH', `forged: status=0, ${PRODUCT_YEAR} + ${PRODUCT_WEEK} valid until 2099`);
    } catch (e) { log('err', `${e}`); }
  }
});

log('init', 'JSONObjectWithData hook armed');

// ────────────────────────────────────────────────────────────
// Lightweight monitoring (read-only, no mutation)
// ────────────────────────────────────────────────────────────
try {
  Interceptor.attach(ObjC.classes.NSURLSession['- dataTaskWithRequest:completionHandler:'].implementation, {
    onEnter(args) {
      try {
        const url = new ObjC.Object(args[2]).URL().absoluteString().toString();
        if (/verifyReceipt|firebaseremoteconfig|firestore/i.test(url)) {
          log('NET', url);
        }
      } catch (_) {}
    }
  });
} catch (_) {}

console.log(`\n${TAG} ready — open Premium and tap Restore Purchases.`);
console.log(`${TAG} when the app calls verifyReceipt, the response will be forged.\n`);
