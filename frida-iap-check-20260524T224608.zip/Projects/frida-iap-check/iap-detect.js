/*
 * Frida script — IAP / Purchase system detector
 * Goal: figure out what replaced StoreKit 2 in the new build
 *
 * Usage:
 *   frida -U -f com.your.bundle -l iap-detect.js --no-pause
 *   # or attach to running app:
 *   frida -U -n "AppName" -l iap-detect.js
 *
 * Run the app, trigger any "purchase" / "subscribe" / "restore" / "premium" flow,
 * then read the console output to see which path lights up.
 */

'use strict';

const TAG = '[IAP-DETECT]';
const log = (cat, msg) => console.log(`${TAG} [${cat}] ${msg}`);
const banner = (t) => console.log(`\n${TAG} ======== ${t} ========`);

// ────────────────────────────────────────────────────────────
// 1) Module / framework presence
// ────────────────────────────────────────────────────────────
banner('LOADED MODULES (filtered)');
const interesting = [
  'StoreKit', 'RevenueCat', 'Purchases', 'Qonversion', 'Adapty',
  'Glassfy', 'Iaphub', 'Paddle', 'Superwall', 'Apphud'
];
Process.enumerateModules().forEach(m => {
  if (interesting.some(k => m.name.toLowerCase().includes(k.toLowerCase()))) {
    log('module', `${m.name}  @ ${m.base}  size=${m.size}`);
  }
});

// ────────────────────────────────────────────────────────────
// 2) StoreKit 1 — Objective-C classes (SKPaymentQueue, etc.)
// ────────────────────────────────────────────────────────────
banner('StoreKit 1 (Objective-C)');
if (ObjC.available) {
  const sk1Classes = [
    'SKPaymentQueue', 'SKPayment', 'SKProduct', 'SKProductsRequest',
    'SKReceiptRefreshRequest', 'SKPaymentTransaction'
  ];
  sk1Classes.forEach(cls => {
    if (ObjC.classes[cls]) {
      log('SK1', `class present: ${cls}`);
    }
  });

  // Hook SKPaymentQueue.addPayment: — fires when StoreKit 1 purchase starts
  try {
    const SKPaymentQueue = ObjC.classes.SKPaymentQueue;
    if (SKPaymentQueue) {
      const m = SKPaymentQueue['- addPayment:'];
      if (m) {
        Interceptor.attach(m.implementation, {
          onEnter(args) {
            const payment = new ObjC.Object(args[2]);
            log('SK1-HIT', `addPayment: productIdentifier=${payment.productIdentifier()}`);
          }
        });
        log('SK1', 'hooked SKPaymentQueue addPayment:');
      }
    }
  } catch (e) { log('SK1', `hook error: ${e}`); }

  // Hook SKProductsRequest start — product lookup
  try {
    const SKProductsRequest = ObjC.classes.SKProductsRequest;
    if (SKProductsRequest) {
      Interceptor.attach(SKProductsRequest['- start'].implementation, {
        onEnter() { log('SK1-HIT', 'SKProductsRequest.start (querying products)'); }
      });
    }
  } catch (e) {}

  // ──────────────────────────────────────────────────────────
  // 3) Third-party IAP SDKs (Obj-C side)
  // ──────────────────────────────────────────────────────────
  banner('Third-party IAP SDKs');
  const sdkClasses = {
    'RevenueCat': ['RCPurchases', 'RCPurchasesAPI', 'RCCustomerInfo', 'RCStoreProduct'],
    'Qonversion': ['QONPurchases', 'Qonversion'],
    'Adapty':     ['Adapty', 'AdaptyPaywall', 'AdaptyProfile'],
    'Glassfy':    ['Glassfy', 'GYSku'],
    'Apphud':     ['Apphud', 'ApphudProduct'],
    'Superwall':  ['Superwall', 'SWPaywallVC']
  };
  Object.keys(sdkClasses).forEach(sdk => {
    const found = sdkClasses[sdk].filter(c => !!ObjC.classes[c]);
    if (found.length) log('SDK', `${sdk} detected → ${found.join(', ')}`);
  });
} else {
  log('warn', 'ObjC runtime not available');
}

// ────────────────────────────────────────────────────────────
// 4) StoreKit 2 (Swift) — Module symbols
//     If these still exist the app could load them lazily
// ────────────────────────────────────────────────────────────
banner('StoreKit 2 (Swift symbols)');
const sk2Symbols = [
  '_$s8StoreKit7ProductV8purchase7optionsAC14PurchaseResultOShyAC0F6OptionVG_tYaKF',
  '_$s8StoreKit11TransactionV6finishyyYaF',
  '_$s8StoreKit03AppA0O4syncyyYaKFZ'
];
const findSym = (name) => {
  try {
    if (typeof Module.findGlobalExportByName === 'function') return Module.findGlobalExportByName(name);
    if (typeof Module.findExportByName === 'function') return Module.findExportByName(null, name);
    return DebugSymbol.fromName(name).address || null;
  } catch (_) { return null; }
};
sk2Symbols.forEach(sym => {
  const addr = findSym(sym);
  log('SK2', `${sym.slice(0, 50)}... → ${addr ? 'PRESENT @ ' + addr : 'MISSING'}`);
});

// ────────────────────────────────────────────────────────────
// 5) Network — see who the app talks to during purchase flow
//     Especially useful to confirm server-side credit / quota model
// ────────────────────────────────────────────────────────────
banner('Network watcher (NSURLSession)');
if (ObjC.available) {
  try {
    const NSURLSession = ObjC.classes.NSURLSession;
    const sel = '- dataTaskWithRequest:completionHandler:';
    if (NSURLSession && NSURLSession[sel]) {
      Interceptor.attach(NSURLSession[sel].implementation, {
        onEnter(args) {
          try {
            const req = new ObjC.Object(args[2]);
            const url = req.URL().absoluteString().toString();
            // filter — only print URLs that look IAP-related
            const keys = /purchase|subscribe|subscription|receipt|premium|entitlement|iap|product|credit|quota|limit|kie\.ai|revenuecat|adapty|qonversion|amazonaws|cloudfunctions/i;
            if (keys.test(url)) {
              log('NET', url);
            }
          } catch (e) {}
        }
      });
      log('NET', 'hooked NSURLSession dataTaskWithRequest:completionHandler:');
    }
  } catch (e) { log('NET', `hook error: ${e}`); }
}

// ────────────────────────────────────────────────────────────
// 6) UserDefaults — apps often cache "is_premium" / credit counts here
// ────────────────────────────────────────────────────────────
banner('UserDefaults watcher');
if (ObjC.available) {
  try {
    const NSUserDefaults = ObjC.classes.NSUserDefaults;
    const setSel = '- setObject:forKey:';
    Interceptor.attach(NSUserDefaults[setSel].implementation, {
      onEnter(args) {
        try {
          const key = new ObjC.Object(args[3]).toString();
          if (/premium|purchase|subscri|credit|count|quota|grok|seedance|omni|video/i.test(key)) {
            const val = new ObjC.Object(args[2]).toString();
            log('DEFAULTS', `${key} = ${val}`);
          }
        } catch (e) {}
      }
    });
    log('DEFAULTS', 'hooked NSUserDefaults setObject:forKey:');
  } catch (e) {}
}

console.log(`\n${TAG} ready. trigger the purchase / premium flow in the app now.\n`);
