'use strict';
const TAG = '[V5]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const NSJSONSerialization = ObjC.classes.NSJSONSerialization;
const NSMutableDictionary = ObjC.classes.NSMutableDictionary;
const NSMutableArray      = ObjC.classes.NSMutableArray;
const NSNumber            = ObjC.classes.NSNumber;
const NSString            = ObjC.classes.NSString;

const FAR_FUTURE_MS = '4070908800000';
const PRODUCT_YEAR  = 'gen_ai_yearly_2999';
const PRODUCT_WEEK  = 'gen_ai_weekly_999';

const strongRefs = [];
const nsStr = (s) => NSString.stringWithString_(s);

const looksLikeAppleReceipt = (d) => {
  try {
    return d.objectForKey_('status') !== null &&
      (d.objectForKey_('receipt') !== null ||
       d.objectForKey_('environment') !== null ||
       d.objectForKey_('latest_receipt') !== null);
  } catch (_) { return false; }
};

const buildReceiptInfo = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(nsStr(pid), 'product_id');
  d.setObject_forKey_(nsStr(FAR_FUTURE_MS), 'expires_date_ms');
  d.setObject_forKey_(nsStr('1000000000000001'), 'transaction_id');
  d.setObject_forKey_(nsStr('1000000000000001'), 'original_transaction_id');
  d.setObject_forKey_(nsStr('1700000000000'), 'purchase_date_ms');
  d.setObject_forKey_(nsStr('1700000000000'), 'original_purchase_date_ms');
  d.setObject_forKey_(nsStr('0'), 'is_trial_period');
  d.setObject_forKey_(nsStr('0'), 'is_in_intro_offer_period');
  d.setObject_forKey_(nsStr('1'), 'quantity');
  d.setObject_forKey_(nsStr('1'), 'web_order_line_item_id');
  return d;
};

const buildRenewal = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(nsStr(pid), 'product_id');
  d.setObject_forKey_(nsStr(pid), 'auto_renew_product_id');
  d.setObject_forKey_(nsStr('1'), 'auto_renew_status');
  return d;
};

const mkArray = (items) => {
  const a = NSMutableArray.alloc().init();
  items.forEach(i => a.addObject_(i));
  return a;
};

Interceptor.attach(NSJSONSerialization['+ JSONObjectWithData:options:error:'].implementation, {
  onLeave(retval) {
    try {
      if (retval.isNull()) return;
      const obj = new ObjC.Object(retval);
      if (!obj.isKindOfClass_(ObjC.classes.NSDictionary)) return;
      if (!looksLikeAppleReceipt(obj)) return;

      const oldStatus = obj.objectForKey_('status');
      const oldStatusInt = oldStatus ? oldStatus.intValue() : -1;
      log('HIT', `Apple receipt status=${oldStatusInt}`);

      if (oldStatusInt === 0) {
        log('SKIP', 'already valid');
        return;
      }

      const mutable = NSMutableDictionary.dictionaryWithDictionary_(obj);
      mutable.setObject_forKey_(NSNumber.numberWithInt_(0), 'status');
      mutable.setObject_forKey_(mkArray([buildReceiptInfo(PRODUCT_YEAR), buildReceiptInfo(PRODUCT_WEEK)]), 'latest_receipt_info');
      mutable.setObject_forKey_(mkArray([buildRenewal(PRODUCT_YEAR), buildRenewal(PRODUCT_WEEK)]), 'pending_renewal_info');
      mutable.setObject_forKey_(nsStr('Production'), 'environment');

      mutable.retain();
      strongRefs.push(mutable);
      retval.replace(mutable.handle);
      log('PATCH', 'forged: status=0');
    } catch (e) { log('err', `${e}`); }
  }
});
log('init', 'forger armed');

const ud = ObjC.classes.NSUserDefaults;
const premKey = /isPremiumUser|isPremium\b/i;

['- boolForKey:', '- integerForKey:'].forEach(sel => {
  Interceptor.attach(ud[sel].implementation, {
    onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
    onLeave(retval) {
      if (this._k && premKey.test(this._k) && retval.toInt32() !== 1) {
        retval.replace(ptr('0x1'));
        log('UD', `${sel} "${this._k}" -> 1`);
      }
    }
  });
});

Interceptor.attach(ud['- objectForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premKey.test(this._k)) {
      try {
        const yes = NSNumber.numberWithBool_(1);
        yes.retain();
        strongRefs.push(yes);
        retval.replace(yes.handle);
        log('UD', `objectForKey "${this._k}" -> @YES`);
      } catch (_) {}
    }
  }
});
log('init', 'UD hooks armed');

setTimeout(() => {
  try {
    ObjC.classes.SKPaymentQueue.defaultQueue().restoreCompletedTransactions();
    log('TRIGGER', 'restore called');
  } catch (e) { log('err', `${e}`); }
}, 5000);

console.log(`${TAG} ready`);
