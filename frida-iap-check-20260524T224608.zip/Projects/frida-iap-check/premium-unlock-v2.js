/*
 * Frida — Premium unlock v2 (safe build)
 *
 * Fixes vs v1:
 *  - removed dangerous Interceptor.replace with NativeCallback (caused crash)
 *  - defers class enumeration until classes are actually loaded
 *  - lighter NSURLSession data-task hook (no completion block rewrite)
 *  - logs which methods get hooked so we can see real coverage
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l premium-unlock-v2.js --no-pause
 */

'use strict';
const TAG = '[UNLOCK]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

// ────────────────────────────────────────────────────────────
// 1) NSUserDefaults — force premium-ish keys (early hook, safe)
// ────────────────────────────────────────────────────────────
const ud = ObjC.classes.NSUserDefaults;
const premiumKey = /premium|isPro|isPaid|isSubscribed|subscription|hasActive/i;

Interceptor.attach(ud['- boolForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premiumKey.test(this._k)) {
      const before = retval.toInt32();
      if (before !== 1) {
        retval.replace(ptr('0x1'));
        log('UD', `boolForKey "${this._k}": ${before} → 1`);
      }
    }
  }
});

Interceptor.attach(ud['- integerForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premiumKey.test(this._k)) {
      if (retval.toInt32() !== 1) {
        retval.replace(ptr('0x1'));
        log('UD', `integerForKey "${this._k}" → 1`);
      }
    }
  }
});

Interceptor.attach(ud['- objectForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premiumKey.test(this._k)) {
      try {
        const yes = ObjC.classes.NSNumber.numberWithBool_(1);
        retval.replace(yes);
        log('UD', `objectForKey "${this._k}" → @YES`);
      } catch (_) {}
    }
  }
});

log('init', 'NSUserDefaults hooks armed');

// ────────────────────────────────────────────────────────────
// 2) Deferred class enumeration (StoreKitManager / StoreKit2Manager)
//     We wait for the classes to register, then hook every method
//     that returns Bool and looks premium-ish.
// ────────────────────────────────────────────────────────────
const targetClasses = [
  'AI_Video_Maker.StoreKitManager',
  'AI_Video_Maker.StoreKit2Manager'
];
const premiumMethod = /(premium|isPro|isPaid|isSubscribed|hasValidSubscription|isPurchased|hasActive|checkSubscription|verifyPurchase|isUserSubscribed)/i;

const hookedClasses = new Set();
const hookClassIfReady = (clsName) => {
  if (hookedClasses.has(clsName)) return true;
  const cls = ObjC.classes[clsName];
  if (!cls) return false;
  hookedClasses.add(clsName);

  let count = 0;
  cls.$ownMethods.forEach(m => {
    if (!premiumMethod.test(m)) return;
    try {
      Interceptor.attach(cls[m].implementation, {
        onLeave(retval) {
          const before = retval.toInt32();
          retval.replace(ptr('0x1'));
          log('METHOD', `${clsName} ${m}  ${before} → 1`);
        }
      });
      log('hook', `${clsName} ${m}`);
      count++;
    } catch (e) { log('err', `${clsName} ${m}: ${e}`); }
  });
  log('init', `${clsName}: hooked ${count} method(s) out of ${cls.$ownMethods.length} total`);
  return true;
};

// try right away — most likely classes already loaded
targetClasses.forEach(c => hookClassIfReady(c));

// fallback: poll every 500ms for up to 15s in case classes load later
let attempts = 0;
const poller = setInterval(() => {
  attempts++;
  let allDone = true;
  targetClasses.forEach(c => { if (!hookClassIfReady(c)) allDone = false; });
  if (allDone || attempts > 30) clearInterval(poller);
}, 500);

// ────────────────────────────────────────────────────────────
// 3) Light NSURLSession watcher — log only, no payload rewrite
//     (the rewrite caused the crash; we drop that for stability)
// ────────────────────────────────────────────────────────────
try {
  const sel = '- dataTaskWithRequest:completionHandler:';
  Interceptor.attach(ObjC.classes.NSURLSession[sel].implementation, {
    onEnter(args) {
      try {
        const req = new ObjC.Object(args[2]);
        const url = req.URL().absoluteString().toString();
        if (/iap|premium|subscri|receipt|verify|firebaseremoteconfig|firestore/i.test(url)) {
          log('NET', url);
        }
      } catch (_) {}
    }
  });
} catch (_) {}

console.log(`\n${TAG} ready. open the paywall / restart the app from the inside (do NOT spawn again).\n`);
