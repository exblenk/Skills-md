/*
 * Frida — Combined unlock v4
 *
 * 3-stage approach:
 *  1. Arm receipt-response forger FIRST (before any verifyReceipt call)
 *  2. Force isPremiumUser=YES in NSUserDefaults
 *  3. Manually trigger SKPaymentQueue restoreCompletedTransactions
 *     → makes the app actually call verifyReceipt → our forger fires
 *
 * Order matters: forger must be active when the response arrives.
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l unlock-v4.js --no-pause
 */

'use strict';
const TAG = '[UNLOCK4]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const NSJSONSerialization = ObjC.classes.NSJSONSerialization;
const NSMutableDictionary = ObjC.classes.NSMutableDictionary;
const NSArray             = ObjC.classes.NSArray;
const NSNumber            = ObjC.classes.NSNumber;
const NSString            = ObjC.classes.NSString;

const FAR_FUTURE_MS = '4070908800000';
const PRODUCT_YEAR  = 'gen_ai_yearly_2999';
const PRODUCT_WEEK  = 'gen_ai_weekly_999';

// ────────────────────────────────────────────────────────────
// STAGE 1 — receipt response forger (must be armed before anything else)
// ────────────────────────────────────────────────────────────
const looksLikeAppleReceipt = (d) => {
  try {
    return d.objectForKey_('status') !== null &&
      (d.objectForKey_('receipt') !== null ||
       d.objectForKey_('environment') !== null ||
       d.objectForKey_('latest_receipt') !== null);
  } catch (_) { return false; }
};

const buildReceiptInfo = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(NSString.stringWithString_(pid), 'product_id');
  d.setObject_forKey_(NSString.stringWithString_(FAR_FUTURE_MS), 'expires_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('1000000000000001'), 'transaction_id');
  d.setObject_forKey_(NSString.stringWithString_('1000000000000001'), 'original_transaction_id');
  d.setObject_forKey_(NSString.stringWithString_('1700000000000'), 'purchase_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('1700000000000'), 'original_purchase_date_ms');
  d.setObject_forKey_(NSString.stringWithString_('0'), 'is_trial_period');
  d.setObject_forKey_(NSString.stringWithString_('0'), 'is_in_intro_offer_period');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'quantity');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'web_order_line_item_id');
  return d;
};

const buildRenewal = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(NSString.stringWithString_(pid), 'product_id');
  d.setObject_forKey_(NSString.stringWithString_(pid), 'auto_renew_product_id');
  d.setObject_forKey_(NSString.stringWithString_('1'), 'auto_renew_status');
  return d;
};

const patchedRefs = [];  // keep strong refs so ObjC objects survive

Interceptor.attach(NSJSONSerialization['+ JSONObjectWithData:options:error:'].implementation, {
  onLeave(retval) {
    try {
      if (retval.isNull()) return;
      const obj = new ObjC.Object(retval);
      if (!obj.isKindOfClass_(ObjC.classes.NSDictionary)) return;
      if (!looksLikeAppleReceipt(obj)) return;

      log('HIT', `Apple receipt response intercepted — status was: ${obj.objectForKey_('status')}`);

      const mutable = NSMutableDictionary.dictionaryWithDictionary_(obj);
      mutable.setObject_forKey_(NSNumber.numberWithInt_(0), 'status');
      mutable.setObject_forKey_(NSArray.arrayWithObjects_(
        buildReceiptInfo(PRODUCT_YEAR),
        buildReceiptInfo(PRODUCT_WEEK),
        null
      ), 'latest_receipt_info');
      mutable.setObject_forKey_(NSArray.arrayWithObjects_(
        buildRenewal(PRODUCT_YEAR),
        buildRenewal(PRODUCT_WEEK),
        null
      ), 'pending_renewal_info');
      mutable.setObject_forKey_(NSString.stringWithString_('Production'), 'environment');

      mutable.retain();
      patchedRefs.push(mutable);
      retval.replace(mutable.handle);
      log('PATCH', `✓ forged response: status=0, yearly+weekly valid until 2099`);
    } catch (e) { log('err', `forger: ${e}`); }
  }
});
log('init', 'Stage 1: receipt forger armed');

// ────────────────────────────────────────────────────────────
// STAGE 2 — UserDefaults isPremiumUser forced to YES
// ────────────────────────────────────────────────────────────
const ud = ObjC.classes.NSUserDefaults;
const premKey = /isPremiumUser|isPremium\b/i;

['- boolForKey:', '- integerForKey:'].forEach(sel => {
  Interceptor.attach(ud[sel].implementation, {
    onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
    onLeave(retval) {
      if (this._k && premKey.test(this._k)) {
        if (retval.toInt32() !== 1) {
          retval.replace(ptr('0x1'));
          log('UD', `${sel} "${this._k}" → 1`);
        }
      }
    }
  });
});

Interceptor.attach(ud['- objectForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premKey.test(this._k)) {
      try {
        const yes = ObjC.classes.NSNumber.numberWithBool_(1);
        retval.replace(yes);
        log('UD', `objectForKey "${this._k}" → @YES`);
      } catch (_) {}
    }
  }
});
log('init', 'Stage 2: UserDefaults hooks armed');

// ────────────────────────────────────────────────────────────
// STAGE 3 — auto-trigger restoreCompletedTransactions after launch
// ────────────────────────────────────────────────────────────
setTimeout(() => {
  try {
    const queue = ObjC.classes.SKPaymentQueue.defaultQueue();
    queue.restoreCompletedTransactions();
    log('TRIGGER', '✓ called restoreCompletedTransactions — verifyReceipt should fire now');
  } catch (e) { log('err', `restore trigger: ${e}`); }
}, 5000);

// ────────────────────────────────────────────────────────────
// Light monitoring
// ────────────────────────────────────────────────────────────
try {
  Interceptor.attach(ObjC.classes.NSURLSession['- dataTaskWithRequest:completionHandler:'].implementation, {
    onEnter(args) {
      try {
        const url = new ObjC.Object(args[2]).URL().absoluteString().toString();
        if (/verifyReceipt|firebaseremoteconfig|firestore|cloudfunctions/i.test(url)) {
          log('NET', url);
        }
      } catch (_) {}
    }
  });
} catch (_) {}

// Transaction observer hook to see results
try {
  const SKPaymentQueue = ObjC.classes.SKPaymentQueue;
  const stateNames = ['Purchasing','Purchased','Failed','Restored','Deferred'];

  // Hook the global delegate path
  ObjC.choose(SKPaymentQueue, {
    onMatch(q) {
      try { log('queue', `SKPaymentQueue instance at ${q.handle}`); } catch (_) {}
    },
    onComplete() {}
  });
} catch (_) {}

console.log(`\n${TAG} ready — auto-trigger fires in 5s. watch for [HIT] [PATCH] [NET].\n`);
