/*
 * Frida — Pure discovery (no modifications)
 *
 * Goal: list ALL methods in StoreKitManager / StoreKit2Manager
 *       so we can pick the right ones to override later.
 *
 * Does NOT touch UserDefaults (avoid anti-tamper trigger).
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l discover.js --no-pause
 */

'use strict';
const TAG = '[DISCOVER]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const targets = [
  'AI_Video_Maker.StoreKitManager',
  'AI_Video_Maker.StoreKit2Manager'
];

const dumpClass = (clsName) => {
  const cls = ObjC.classes[clsName];
  if (!cls) { log('skip', `${clsName} not loaded yet`); return false; }

  log('class', `═══════ ${clsName} ═══════`);
  const own = cls.$ownMethods.sort();
  own.forEach(m => log('m', `  ${m}`));
  log('class', `total: ${own.length} methods`);

  // Also dump ivars to find premium-state storage
  try {
    const ivars = Object.keys(cls.$ivars || {});
    if (ivars.length) {
      log('ivars', `${clsName} ivars:`);
      ivars.forEach(i => log('iv', `  ${i}`));
    }
  } catch (_) {}
  return true;
};

const found = new Set();
const tryAll = () => {
  targets.forEach(t => {
    if (found.has(t)) return;
    if (dumpClass(t)) found.add(t);
  });
};

tryAll();

let n = 0;
const poller = setInterval(() => {
  n++;
  tryAll();
  if (found.size === targets.length || n > 30) {
    clearInterval(poller);
    if (found.size < targets.length) {
      log('warn', 'some classes never loaded — paywall may not have opened');
    }
  }
}, 500);

// Trace any premium-related Apple framework calls — purely passive
try {
  Interceptor.attach(ObjC.classes.NSURLSession['- dataTaskWithRequest:completionHandler:'].implementation, {
    onEnter(args) {
      try {
        const url = new ObjC.Object(args[2]).URL().absoluteString().toString();
        if (/verifyReceipt|firebaseremoteconfig|firestore|iap|premium|subscri/i.test(url)) {
          log('NET', url);
        }
      } catch (_) {}
    }
  });
} catch (_) {}

console.log(`\n${TAG} discovery armed — open Premium screen, then read the dump above.\n`);
