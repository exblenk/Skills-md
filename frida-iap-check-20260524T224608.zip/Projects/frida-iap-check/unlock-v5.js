/*
 * Frida — Unlock v5 (fixed array construction crash)
 *
 * Bug in v4: NSArray.arrayWithObjects_(..., null) — variadic, Frida bridge
 * doesn't handle nil-terminator correctly. Switched to NSMutableArray.addObject_.
 *
 * Also: only patch when status != 0 (don't touch already-valid responses).
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l unlock-v5.js --no-pause
 */

'use strict';
const TAG = '[V5]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

const NSJSONSerialization = ObjC.classes.NSJSONSerialization;
const NSMutableDictionary = ObjC.classes.NSMutableDictionary;
const NSMutableArray      = ObjC.classes.NSMutableArray;
const NSNumber            = ObjC.classes.NSNumber;
const NSString            = ObjC.classes.NSString;

const FAR_FUTURE_MS = '4070908800000';
const PRODUCT_YEAR  = 'gen_ai_yearly_2999';
const PRODUCT_WEEK  = 'gen_ai_weekly_999';

const strongRefs = [];   // keep ObjC objects alive

const nsStr = (s) => NSString.stringWithString_(s);

const looksLikeAppleReceipt = (d) => {
  try {
    return d.objectForKey_('status') !== null &&
      (d.objectForKey_('receipt') !== null ||
       d.objectForKey_('environment') !== null ||
       d.objectForKey_('latest_receipt') !== null);
  } catch (_) { return false; }
};

const buildReceiptInfo = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(nsStr(pid),                  'product_id');
  d.setObject_forKey_(nsStr(FAR_FUTURE_MS),        'expires_date_ms');
  d.setObject_forKey_(nsStr('1000000000000001'),   'transaction_id');
  d.setObject_forKey_(nsStr('1000000000000001'),   'original_transaction_id');
  d.setObject_forKey_(nsStr('1700000000000'),      'purchase_date_ms');
  d.setObject_forKey_(nsStr('1700000000000'),      'original_purchase_date_ms');
  d.setObject_forKey_(nsStr('0'),                  'is_trial_period');
  d.setObject_forKey_(nsStr('0'),                  'is_in_intro_offer_period');
  d.setObject_forKey_(nsStr('1'),                  'quantity');
  d.setObject_forKey_(nsStr('1'),                  'web_order_line_item_id');
  return d;
};

const buildRenewal = (pid) => {
  const d = NSMutableDictionary.alloc().init();
  d.setObject_forKey_(nsStr(pid),  'product_id');
  d.setObject_forKey_(nsStr(pid),  'auto_renew_product_id');
  d.setObject_forKey_(nsStr('1'), 'auto_renew_status');
  return d;
};

const mkArray = (...items) => {
  const a = NSMutableArray.alloc().init();
  items.forEach(i => a.addObject_(i));
  return a;
};

// ────────────────────────────────────────────────────────────
// Receipt forger
// ────────────────────────────────────────────────────────────
Interceptor.attach(NSJSONSerialization['+ JSONObjectWithData:options:error:'].implementation, {
  onLeave(retval) {
    try {
      if (retval.isNull()) return;
      const obj = new ObjC.Object(retval);
      if (!obj.isKindOfClass_(ObjC.classes.NSDictionary)) return;
      if (!looksLikeAppleReceipt(obj)) return;

      const oldStatus = obj.objectForKey_('status');
      const oldStatusInt = oldStatus ? oldStatus.intValue() : -1;
      log('HIT', `Apple receipt — status=${oldStatusInt}`);

      // If Apple already says valid (status 0), don't touch
      if (oldStatusInt === 0) {
        log('SKIP', 'status already 0 — letting through unchanged');
        return;
      }

      // Otherwise, patch
      const mutable = NSMutableDictionary.dictionaryWithDictionary_(obj);
      mutable.setObject_forKey_(NSNumber.numberWithInt_(0), 'status');

      const receiptArr = mkArray(
        buildReceiptInfo(PRODUCT_YEAR),
        buildReceiptInfo(PRODUCT_WEEK)
      );
      mutable.setObject_forKey_(receiptArr, 'latest_receipt_info');

      const renewArr = mkArray(
        buildRenewal(PRODUCT_YEAR),
        buildRenewal(PRODUCT_WEEK)
      );
      mutable.setObject_forKey_(renewArr, 'pending_renewal_info');

      mutable.setObject_forKey_(nsStr('Production'), 'environment');

      mutable.retain();
      strongRefs.push(mutable);
      retval.replace(mutable.handle);
      log('PATCH', '✓ forged: status=0, yearly+weekly until 2099');
    } catch (e) { log('err', `forger: ${e}\n${e.stack || ''}`); }
  }
});
log('init', 'receipt forger armed (safe array construction)');

// ────────────────────────────────────────────────────────────
// UserDefaults: force isPremiumUser → YES
// ────────────────────────────────────────────────────────────
const ud = ObjC.classes.NSUserDefaults;
const premKey = /isPremiumUser|isPremium\b/i;

['- boolForKey:', '- integerForKey:'].forEach(sel => {
  Interceptor.attach(ud[sel].implementation, {
    onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
    onLeave(retval) {
      if (this._k && premKey.test(this._k) && retval.toInt32() !== 1) {
        retval.replace(ptr('0x1'));
        log('UD', `${sel} "${this._k}" → 1`);
      }
    }
  });
});

Interceptor.attach(ud['- objectForKey:'].implementation, {
  onEnter(args) { try { this._k = new ObjC.Object(args[2]).toString(); } catch (_) {} },
  onLeave(retval) {
    if (this._k && premKey.test(this._k)) {
      try {
        const yes = NSNumber.numberWithBool_(1);
        yes.retain();
        strongRefs.push(yes);
        retval.replace(yes.handle);
        log('UD', `objectForKey "${this._k}" → @YES`);
      } catch (_) {}
    }
  }
});
log('init', 'UserDefaults hooks armed');

// ────────────────────────────────────────────────────────────
// Trigger restore after app settles (only if not already triggered)
// ────────────────────────────────────────────────────────────
setTimeout(() => {
  try {
    ObjC.classes.SKPaymentQueue.defaultQueue().restoreCompletedTransactions();
    log('TRIGGER', '✓ restoreCompletedTransactions called');
  } catch (e) { log('err', `trigger: ${e}`); }
}, 5000);

// Light NET monitor
try {
  Interceptor.attach(ObjC.classes.NSURLSession['- dataTaskWithRequest:completionHandler:'].implementation, {
    onEnter(args) {
      try {
        const url = new ObjC.Object(args[2]).URL().absoluteString().toString();
        if (/verifyReceipt|firebaseremoteconfig|cloudfunctions|firestore/i.test(url)) {
          log('NET', url);
        }
      } catch (_) {}
    }
  });
} catch (_) {}

console.log(`\n${TAG} ready. trigger fires in 5s.\n`);
