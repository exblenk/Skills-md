# IAP detector — Frida script

Confirms what replaced StoreKit 2 in the new binary.

## ما الذي يفعله السكريبت

السكريبت يفحص ستة محاور بالتوازي:

1. **Modules المحملة** — يطبع أي framework من قائمة IAP SDKs معروفة (StoreKit, RevenueCat, Qonversion, Adapty, Glassfy, Apphud, Superwall).
2. **StoreKit 1 (Obj-C)** — يفحص وجود `SKPaymentQueue`, `SKProduct`, `SKProductsRequest` ويعترض `addPayment:` ليلتقط أي شراء فعلي.
3. **SDKs خارجية** — يبحث عن كلاسات RevenueCat (`RCPurchases`)، Qonversion، Adapty، إلخ.
4. **StoreKit 2 (Swift)** — يتحقق من رموز `Product.purchase`, `Transaction.finish`, `AppStore.sync` (التي اختفت من النسخة الجديدة).
5. **مراقب الشبكة** — يعترض `NSURLSession dataTaskWithRequest:completionHandler:` ويطبع فقط الـ URLs المتعلقة بالشراء/الكوتا/الاشتراكات.
6. **NSUserDefaults** — يلتقط أي مفاتيح خاصة بـ premium / credits / video counts.

## التشغيل

```bash
# على جهاز iOS مكسور الحماية (jailbroken) + frida-server مشغّل
frida -U -f com.bundle.id -l iap-detect.js --no-pause

# أو اتصال بتطبيق شغّال
frida -U -n "AppName" -l iap-detect.js
```

ثم في التطبيق:
- افتح شاشة "Premium" / "Upgrade"
- جرّب توليد فيديو بـ Seedance / Grok / Omni
- اضغط "Restore Purchases" لو موجود
- راقب الـ console

## كيف تفسر النتيجة

| اللي ظهر | الاستنتاج |
|---|---|
| `SK1-HIT SKPaymentQueue.addPayment:` | رجعوا لـ StoreKit 1 الكلاسيكي |
| `SDK RevenueCat detected` | استعانوا بـ RevenueCat كـ wrapper |
| `SDK Adapty/Qonversion detected` | SDK خارجي تاني |
| `SK2 ... PRESENT` | StoreKit 2 لسه موجود لكن مش متستدعى مباشرة (مستبعد) |
| طلبات `kie.ai` أو `cloudfunctions.net` أو AWS execute-api فقط بدون أي IAP hit | نموذج server-side quota / credits بدون اشتراك أصلاً |
| `DEFAULTS grokVideoCount=...` | تأكيد إن النموذج بقى عدّاد محلي مرتبط بسيرفر |

## ملاحظة

- يحتاج جهاز جيلبريك أو نسخة `Frida.dylib` محقونة (objection patchapp / re-sign).
- لو بتختبر على Simulator، استبدل `-U` بـ `--device local`.
