/*
 * Frida — Premium unlock for security testing
 * Target: com.saidul.aivideo (AI_Video_Maker)
 *
 * Strategy (three layers — كلهم بيشتغلوا مع بعض):
 *  1) Hook every method في StoreKitManager / StoreKit2Manager بيرجع Bool
 *     واللي اسمه فيه premium/isPro/isPaid/isSubscribed → force true
 *  2) NSUserDefaults: أي قراءة لمفتاح فيه "premium" → force YES
 *  3) Remote Config JSON: أي response فيه is_free_limit أو is_premium → نزود is_premium=true
 *
 * USAGE:
 *   frida -U -f com.saidul.aivideo -l premium-unlock.js --no-pause
 */

'use strict';
const TAG = '[PREMIUM-UNLOCK]';
const log = (c, m) => console.log(`${TAG} [${c}] ${m}`);

if (!ObjC.available) throw new Error('ObjC unavailable');

// ────────────────────────────────────────────────────────────
// 1) Hook every premium-looking method in the app's Swift classes
// ────────────────────────────────────────────────────────────
const targetClasses = [
  'AI_Video_Maker.StoreKitManager',
  'AI_Video_Maker.StoreKit2Manager'
];
const premiumPattern = /(premium|isPro|isPaid|isSubscribed|hasValidSubscription|isPurchased|hasActive)/i;

targetClasses.forEach(clsName => {
  const cls = ObjC.classes[clsName];
  if (!cls) { log('skip', `class not found: ${clsName}`); return; }

  const methods = cls.$ownMethods;
  methods.forEach(m => {
    if (!premiumPattern.test(m)) return;
    try {
      const impl = cls[m].implementation;
      Interceptor.attach(impl, {
        onLeave(retval) {
          const before = retval.toInt32();
          retval.replace(ptr('0x1'));  // BOOL = YES / true
          log('OVERRIDE', `${clsName} ${m}  ${before} → 1`);
        }
      });
      log('hook', `${clsName} ${m}`);
    } catch (e) { log('err', `${clsName} ${m}: ${e}`); }
  });
});

// ────────────────────────────────────────────────────────────
// 2) NSUserDefaults — force any premium key to YES / non-zero
// ────────────────────────────────────────────────────────────
const ud = ObjC.classes.NSUserDefaults;
const premiumKey = /premium|isPro|isPaid|isSubscribed|subscription/i;

Interceptor.attach(ud['- boolForKey:'].implementation, {
  onEnter(args) {
    try {
      const key = new ObjC.Object(args[2]).toString();
      this._key = key;
      this._isPremium = premiumKey.test(key);
    } catch (e) {}
  },
  onLeave(retval) {
    if (this._isPremium) {
      const before = retval.toInt32();
      retval.replace(ptr('0x1'));
      log('UD', `boolForKey "${this._key}": ${before} → 1`);
    }
  }
});

Interceptor.attach(ud['- objectForKey:'].implementation, {
  onEnter(args) {
    try {
      const key = new ObjC.Object(args[2]).toString();
      this._key = key;
      this._isPremium = premiumKey.test(key);
    } catch (e) {}
  },
  onLeave(retval) {
    if (this._isPremium) {
      // Replace with NSNumber @YES so legacy code paths see truthy value
      try {
        const yes = ObjC.classes.NSNumber.numberWithBool_(1);
        retval.replace(yes);
        log('UD', `objectForKey "${this._key}" → @YES`);
      } catch (e) {}
    }
  }
});

Interceptor.attach(ud['- integerForKey:'].implementation, {
  onEnter(args) {
    try {
      const key = new ObjC.Object(args[2]).toString();
      this._key = key;
      this._isPremium = premiumKey.test(key);
    } catch (e) {}
  },
  onLeave(retval) {
    if (this._isPremium) {
      retval.replace(ptr('0x1'));
      log('UD', `integerForKey "${this._key}" → 1`);
    }
  }
});

// ────────────────────────────────────────────────────────────
// 3) Remote Config JSON patching
//     The /firebase endpoint sends is_free_limit / iap_* — we tweak the payload
//     so the app sees the user as already-premium (defensive)
// ────────────────────────────────────────────────────────────
try {
  const NSData = ObjC.classes.NSData;
  const NSString = ObjC.classes.NSString;

  // hook -[NSURLSession dataTaskWithRequest:completionHandler:] to wrap completion
  const sessionCls = ObjC.classes.NSURLSession;
  const sel = '- dataTaskWithRequest:completionHandler:';
  const original = sessionCls[sel].implementation;

  const Block = ObjC.Block;
  const newImpl = new NativeCallback(function (self, _cmd, request, completion) {
    if (completion.isNull()) return original(self, _cmd, request, completion);
    try {
      const block = new ObjC.Block(completion);
      const inner = block.implementation;
      block.implementation = function (data, response, error) {
        try {
          if (!data.isNull()) {
            const dObj = new ObjC.Object(data);
            const s = NSString.alloc().initWithData_encoding_(dObj, 4); // UTF8
            if (s) {
              let txt = s.toString();
              if (/is_free_limit|iap_yearly_key|isPremium/i.test(txt)) {
                let patched = txt
                  .replace(/"is_free_limit"\s*:\s*true/gi,  '"is_free_limit":false')
                  .replace(/"is_premium"\s*:\s*false/gi,    '"is_premium":true')
                  .replace(/"isPremium"\s*:\s*false/gi,     '"isPremium":true');
                if (patched !== txt) {
                  log('JSON', 'patched remote-config response → premium flags forced');
                  const newData = NSString.stringWithString_(patched)
                    .dataUsingEncoding_(4);
                  return inner(newData, response, error);
                }
              }
            }
          }
        } catch (e) {}
        return inner(data, response, error);
      };
    } catch (e) {}
    return original(self, _cmd, request, completion);
  }, 'pointer', ['pointer', 'pointer', 'pointer', 'pointer']);
  Interceptor.replace(original, newImpl);
  log('hook', 'NSURLSession completion block wrapped');
} catch (e) { log('err', `JSON patcher: ${e}`); }

console.log(`\n${TAG} ready — open Premium screen / restart paywall flow now.`);
console.log(`${TAG} all premium checks will be forced to TRUE.\n`);
